import UIKit

let pi = 3.14


var x1 = 100
var x2 = 0.5
var x3 = Double(x1) + x2

print("x3 = \(x3)")

var opt:Int? = 3
opt = nil

var tuple = (1, 2.0, "cu", false)
var (a,b,c,d) = tuple
print("gia tri thu 4 cua tuple la: \(tuple.3)")
print(a)
print(tuple.3)

var boss : Int
var a1 = 15
var a2 = 5
boss = a1 > a2 ? a1 : a2

var b1 = 5
if b1 > 0 {
    print("b1 lon hon 0")
} else {
    print("b1 nho hon hoac bang 0")
}

let distance = 5
switch distance {
case 0...9 :
    print("gan, tan dc")
case 10...500 :
    print("hoi xa, lay xe chay di tan")
default :
    print("xa qua, thoi")
}

var text = "ABC"
text.append("D")


